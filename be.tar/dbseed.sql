DROP TABLE IF EXISTS conferences;

CREATE TABLE IF NOT EXISTS conferences (
        id INT NOT NULL AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        date INT(11) NOT NULL,
        location POINT NOT NULL,
        country VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        PRIMARY KEY (id),
        SPATIAL INDEX `SPATIAL` (`location`)
    ) ENGINE=INNODB;

INSERT INTO conferences
        (name, date, location, country)
    VALUES
        ('NAME_TEST_1', 1661004969, Point(34,35), 'UKRAINE'),
        ('NAME_TEST_2', 1661204969, Point(34,35.4232), 'GREAT BRITAIN');