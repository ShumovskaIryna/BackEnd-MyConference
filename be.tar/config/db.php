<?php
return [
    //TODO: should be get from ENVs
    'host' => '127.0.0.1',
    'dbname' => 'conf',
    'user' => 'conf',
    'password' => 'conf',
];